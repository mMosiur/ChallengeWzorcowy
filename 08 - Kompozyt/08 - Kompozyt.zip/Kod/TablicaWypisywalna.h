#pragma once

// Klasa interfejsu
class TablicaWypisywalna {
public:
    virtual void wypisz(bool enter = true) = 0;
};

