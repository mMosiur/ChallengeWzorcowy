#pragma once
class Noz {
public:
    virtual void przekroj() = 0;
};