#pragma once
class Widelec {
public:
    virtual void nabij() = 0;
};