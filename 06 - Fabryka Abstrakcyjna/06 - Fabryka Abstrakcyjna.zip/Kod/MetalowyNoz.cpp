#include "MetalowyNoz.h"
#include <iostream>

void MetalowyNoz::przekroj() {
    std::cout << "Kroje metalowym nozem" << std::endl;
}