#include "PlastikowyNoz.h"
#include <iostream>

void PlastikowyNoz::przekroj() {
    std::cout << "Kroje plastikowym nozem" << std::endl;
}