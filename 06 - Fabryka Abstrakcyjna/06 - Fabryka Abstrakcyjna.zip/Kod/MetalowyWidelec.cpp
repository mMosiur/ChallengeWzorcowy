#include "MetalowyWidelec.h"
#include <iostream>

void MetalowyWidelec::nabij() {
    std::cout << "Nabijam metalowym nozem" << std::endl;
}