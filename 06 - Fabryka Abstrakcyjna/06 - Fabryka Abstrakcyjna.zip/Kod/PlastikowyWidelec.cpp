#include "PlastikowyWidelec.h"
#include <iostream>

void PlastikowyWidelec::nabij() {
    std::cout << "Nabijam plastikowym widelcem" << std::endl;
}