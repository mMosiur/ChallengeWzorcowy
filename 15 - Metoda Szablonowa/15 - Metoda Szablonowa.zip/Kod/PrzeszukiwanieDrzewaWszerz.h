#pragma once
#include "PrzeszukiwanieDrzewa.h"

class PrzeszukiwanieDrzewaWszerz : public PrzeszukiwanieDrzewa {
public:
    W�ze�Drzewa* we�_nast�pny();
};

