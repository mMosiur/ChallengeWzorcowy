#pragma once
#include "PrzeszukiwanieDrzewa.h"
class PrzeszukiwanieDrzewaWg��b : public PrzeszukiwanieDrzewa {
public:
    W�ze�Drzewa* we�_nast�pny();
};

