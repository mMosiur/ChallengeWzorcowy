#pragma once
class Prototyp {
public:
    virtual Prototyp* clone() = 0;
};

