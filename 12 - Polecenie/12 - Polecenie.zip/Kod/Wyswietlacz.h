#pragma once
#include <vector>
#include "Tekst.h"

class Wyswietlacz {
public:
    std::vector<Tekst> teksty;
    void wyswietl();
};

