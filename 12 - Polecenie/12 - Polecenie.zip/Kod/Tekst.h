#pragma once
#include <iostream>

class Tekst {
public:
    std::string zawartosc; // Tre�� tekstu

    Tekst(std::string tekst);

    void wypisz();
};

