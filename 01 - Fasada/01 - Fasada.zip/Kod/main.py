from FasadaRobota import FasadaRobota

robot = FasadaRobota()
robot.jedź_prosto(10)
robot.włącz()
robot.jedź_prosto(10)
robot.jedź_prosto(-10)
robot.skręć(100)

