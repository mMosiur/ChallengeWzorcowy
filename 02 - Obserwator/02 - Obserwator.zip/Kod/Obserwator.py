class Obserwator:
    def __init__(self):
        raise NotImplementedError("Klasa jest interfejsem")

    def aktualizacja(self, podmiot):
        raise NotImplementedError("Klasa jest interfejsem")

