class Urządzenie:
    def __init__(self):
        raise NotImplementedError("Klasa jest interfejsem")

    def włącz(self):
        raise NotImplementedError("Klasa jest interfejsem")

    def wyłącz(self):
        raise NotImplementedError("Klasa jest interfejsem")

