#include "WeryfikatorP�ci.h"

bool WeryfikatorP�ci::weryfikuj(Osoba* osoba) {
    return osoba->p�e� == P�e�::K;
}
