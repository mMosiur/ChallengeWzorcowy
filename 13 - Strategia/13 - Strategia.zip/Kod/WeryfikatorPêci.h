#pragma once
#include "Weryfikator.h"
class WeryfikatorP�ci : public Weryfikator {
public:
    bool weryfikuj(Osoba* osoba);
};

