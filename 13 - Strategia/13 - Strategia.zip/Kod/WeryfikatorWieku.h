#pragma once
#include "Weryfikator.h"
class WeryfikatorWieku : public Weryfikator {
public:
    bool weryfikuj(Osoba* osoba);
};

